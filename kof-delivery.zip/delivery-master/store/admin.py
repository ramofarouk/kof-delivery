from django.contrib import admin
from store.models import Store, Task,DeliveryBoy
# Register your models here.


admin.site.register(Store)
admin.site.register(Task)
admin.site.register(DeliveryBoy)