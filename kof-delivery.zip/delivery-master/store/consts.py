validation_messages = {
	"DUPLICATE_STORE": "Duplicate store found",
	"DUPLICATE_NUMBER": "Duplicate Number found",
}